Responsive HTML5 website template for startups

Theme name:
=======================================================================
Tempo

Theme version:
=======================================================================
v1.7

Release Date:
=======================================================================
27 July 2016

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Facebook: https://www.facebook.com/3rdwavethemes/
Twitter: 3rdwave_themes

